import streamlit as st
from pymongo import MongoClient
import pandas as pd
from bson.objectid import ObjectId

# Conexão com o MongoDB
client = MongoClient("mongodb://mongodb:27017/")
db = client["eshop"]
...
